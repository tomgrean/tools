﻿数据库为postgresql，数据库字符编码使用UTF-8
db.dump文件的编码是UTF-8，unix换行格式。
数据库文件导入方式有很多种，这里说一种(例如文件是在当前目录下的db.dump.txt)：
1. 创建一个空数据库。用psql命令连上。
2. 用文本编辑器打开db.dump.txt，全文替换其中的“pieshudian”为你使用的SQL账户名。
3. 在psql命令中输入：
\i db.dump.txt


主要表有：
word      单字全码表。
word_1s   一级简码表。
word_2s   二级简码表。
word_3s   三级简码表。
phrase    词组表。
phrase_1s 一级简码词组表。
phrase_2s 二级简码词组表（暂未用）。
element   字根表（仅查询用）。

视图有：
word1v    基于word_1s，用word表构建码表。
word2v    基于word_2s，用word表构建码表。
word3v    基于word_3s，用word表构建码表。
phrase1v  基于phrase_1s，用word表构建码表。
phrase2v  基于phrase_2s，用word表构建码表。

allcodeword  基于各个码表的数据，生成最终的码表（目前包含gbk单字、一简字、一简词、二简字、三简字、词）。

还有以下两个工具视图，用于查询编码相同且频率（用于编码排序）相同的编码。此类数据需要调整频率，否则不能保证每次生成码表的顺序是一样的。
find_dup_phrase_freq  查找phrase表不能排序的数据
find_dup_word_freq    查找word表不能排序的数据

函数有：
phrasev   基于phrase，用word表构建码表。
存储过程有：
reset_phrase        用word码表刷新phrase表中的编码。
reset_shortcut_code 用word码表刷新各简码表中的编码。

=======================================================
使用说明：
1. 单字码表更新，直接修改word表，更新单字的编码或使用频率等信息。注意修改字的编码后，可能会造成与此字相关的简码、词的编码变化，没关系。生成码表时简码都是使用视图生成的，词用函数生成，但是单独查询时会受到一定的干扰和影响。
数据库中定义了2个存储过程，可以完成这个功能：
call reset_phrase
call reset_shortcut_code

2. 字、词简码更新，直接修改相应的word_Xs/phrase_Xs表即可。

3. 词的导入与更新，直接修改phrase表。导入词的时候，要导入词的使用频率，不用关心词的编码，例如：
insert into phrase values('@@@@', '更新', 100000);
词语导入之后，想要看编码，执行一次call reset_phrase，更新编码。

4. 字、简码、词更新后，要查询一下编码、使用频率重复的条目，如果有，建议手动修改每条的频率。

5. 码表生成，在psql命令行中，可以执行以下步骤：
㈠
\o output.txt
使输出到指定的文件中去。
㈡
select * from allcodeword;
㈢
\q
退出psql程序
㈣
用文本编辑工具打开output.txt文件，去掉文件头尾的多余数据
㈤
执行全文替换，将空格删除，然后根据需要将|替换成Tab或者空格。
㈥
根据具体输入法的需要，处理文件编码、格式，增加文件头等等。
㈦
导入到输入法中使用。
